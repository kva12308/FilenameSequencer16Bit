@echo off
title Build Urutkan File
echo Membuat aplikasi Urutkan File...
py -m pip install --upgrade pyinstaller
if errorlevel 1 (
  echo Gagal memasang PyInstaller. Pastikan Python terpasang.
  pause
  exit /b 1
)
py -m PyInstaller --noconfirm --clean --onefile --windowed --name "UrutkanFile" urutkan_file.pyw
if errorlevel 1 (
  echo Proses build gagal.
  pause
  exit /b 1
)
echo.
echo Selesai! Aplikasi ada di folder dist\UrutkanFile.exe
pause
