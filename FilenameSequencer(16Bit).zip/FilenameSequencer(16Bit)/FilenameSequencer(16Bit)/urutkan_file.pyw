import os
import uuid
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path

APP_TITLE = "Urutkan File Setup"

# 25 widely used languages. The selector translates the main installer interface.
LANGUAGES = {
    "English": {
        "subtitle": "Choose the folder containing the files you want to rename.",
        "folder": "Folder containing files",
        "browse": "Browse...",
        "preview": "File name preview",
        "old": "CURRENT FILE NAME",
        "new": "NEW FILE NAME",
        "rename": "Rename Files",
        "cancel": "Cancel",
        "count": "{n} files",
        "hint": "Only files in this folder are renamed. Subfolders are left unchanged.",
        "confirm": "Rename all {n} files in this folder?",
        "success": "Successfully renamed {n} files.",
        "no_folder": "Please choose a folder first.",
        "choose": "Choose Folder",
        "window": "Urutkan File Setup",
    },
    "Bahasa Indonesia": {
        "subtitle": "Pilih folder yang berisi file yang ingin kamu ganti namanya.",
        "folder": "Folder yang berisi file",
        "browse": "Telusuri...",
        "preview": "Pratinjau nama file",
        "old": "NAMA FILE SAAT INI",
        "new": "NAMA FILE BARU",
        "rename": "Ganti Nama File",
        "cancel": "Batal",
        "count": "{n} file",
        "hint": "Hanya file di folder ini yang diubah. Subfolder tidak ikut diubah.",
        "confirm": "Ganti nama semua {n} file di folder ini?",
        "success": "{n} file berhasil diganti namanya.",
        "no_folder": "Pilih folder terlebih dahulu.",
        "choose": "Pilih Folder",
        "window": "Pengaturan Urutkan File",
    },
    "Español": {
        "subtitle": "Elige la carpeta que contiene los archivos que quieres renombrar.",
        "folder": "Carpeta de archivos", "browse": "Examinar...",
        "preview": "Vista previa de nombres", "old": "NOMBRE ACTUAL", "new": "NOMBRE NUEVO",
        "rename": "Renombrar archivos", "cancel": "Cancelar", "count": "{n} archivos",
        "hint": "Solo se renombran los archivos de esta carpeta; las subcarpetas no cambian.",
        "confirm": "¿Renombrar los {n} archivos de esta carpeta?", "success": "Se renombraron {n} archivos.",
        "no_folder": "Primero elige una carpeta.", "choose": "Elegir carpeta", "window": "Instalación de Urutkan File",
    },
    "中文 (简体)": {
        "subtitle": "选择包含要重命名文件的文件夹。", "folder": "文件夹", "browse": "浏览...",
        "preview": "文件名预览", "old": "当前文件名", "new": "新文件名", "rename": "重命名文件",
        "cancel": "取消", "count": "{n} 个文件", "hint": "只重命名此文件夹中的文件，不更改子文件夹。",
        "confirm": "要重命名此文件夹中的 {n} 个文件吗？", "success": "已重命名 {n} 个文件。",
        "no_folder": "请先选择文件夹。", "choose": "选择文件夹", "window": "文件排序设置",
    },
    "हिन्दी": {
        "subtitle": "उन फ़ाइलों वाला फ़ोल्डर चुनें जिनका नाम बदलना है।", "folder": "फ़ाइल फ़ोल्डर", "browse": "ब्राउज़...",
        "preview": "फ़ाइल नाम पूर्वावलोकन", "old": "मौजूदा फ़ाइल नाम", "new": "नया फ़ाइल नाम", "rename": "फ़ाइलों के नाम बदलें",
        "cancel": "रद्द करें", "count": "{n} फ़ाइलें", "hint": "केवल इस फ़ोल्डर की फ़ाइलों के नाम बदलेंगे; सबफ़ोल्डर नहीं बदलेंगे।",
        "confirm": "क्या इस फ़ोल्डर की {n} फ़ाइलों के नाम बदलें?", "success": "{n} फ़ाइलों के नाम बदल दिए गए।",
        "no_folder": "पहले फ़ोल्डर चुनें।", "choose": "फ़ोल्डर चुनें", "window": "फ़ाइल क्रम सेटअप",
    },
    "العربية": {
        "subtitle": "اختر المجلد الذي يحتوي على الملفات التي تريد إعادة تسميتها.", "folder": "مجلد الملفات", "browse": "استعراض...",
        "preview": "معاينة أسماء الملفات", "old": "الاسم الحالي", "new": "الاسم الجديد", "rename": "إعادة تسمية الملفات",
        "cancel": "إلغاء", "count": "{n} ملفات", "hint": "تتم إعادة تسمية الملفات في هذا المجلد فقط، دون المجلدات الفرعية.",
        "confirm": "هل تريد إعادة تسمية {n} ملفات؟", "success": "تمت إعادة تسمية {n} ملفات.",
        "no_folder": "يرجى اختيار مجلد أولاً.", "choose": "اختيار مجلد", "window": "إعداد ترتيب الملفات",
    },
    "Português": {
        "subtitle": "Escolha a pasta com os arquivos que deseja renomear.", "folder": "Pasta de arquivos", "browse": "Procurar...",
        "preview": "Prévia dos nomes", "old": "NOME ATUAL", "new": "NOVO NOME", "rename": "Renomear arquivos",
        "cancel": "Cancelar", "count": "{n} arquivos", "hint": "Só os arquivos desta pasta serão renomeados; subpastas não serão alteradas.",
        "confirm": "Renomear os {n} arquivos desta pasta?", "success": "{n} arquivos renomeados.",
        "no_folder": "Escolha uma pasta primeiro.", "choose": "Escolher pasta", "window": "Configuração de arquivos",
    },
    "বাংলা": {
        "subtitle": "যে ফোল্ডারের ফাইলগুলোর নাম বদলাতে চান সেটি বেছে নিন।", "folder": "ফাইল ফোল্ডার", "browse": "ব্রাউজ...",
        "preview": "ফাইলের নামের পূর্বরূপ", "old": "বর্তমান নাম", "new": "নতুন নাম", "rename": "ফাইলের নাম বদলান",
        "cancel": "বাতিল", "count": "{n}টি ফাইল", "hint": "শুধু এই ফোল্ডারের ফাইল বদলাবে; সাবফোল্ডার অপরিবর্তিত থাকবে।",
        "confirm": "এই ফোল্ডারের {n}টি ফাইলের নাম বদলাবেন?", "success": "{n}টি ফাইলের নাম বদলানো হয়েছে।",
        "no_folder": "আগে একটি ফোল্ডার বেছে নিন।", "choose": "ফোল্ডার বাছুন", "window": "ফাইল সাজানোর সেটআপ",
    },
    "Русский": {
        "subtitle": "Выберите папку с файлами, которые нужно переименовать.", "folder": "Папка с файлами", "browse": "Обзор...",
        "preview": "Предпросмотр имён", "old": "ТЕКУЩЕЕ ИМЯ", "new": "НОВОЕ ИМЯ", "rename": "Переименовать файлы",
        "cancel": "Отмена", "count": "{n} файлов", "hint": "Переименуются только файлы в этой папке; подпапки не изменятся.",
        "confirm": "Переименовать {n} файлов в этой папке?", "success": "Переименовано файлов: {n}.",
        "no_folder": "Сначала выберите папку.", "choose": "Выбрать папку", "window": "Настройка сортировки файлов",
    },
    "日本語": {
        "subtitle": "名前を変更するファイルが入ったフォルダーを選択してください。", "folder": "ファイルのフォルダー", "browse": "参照...",
        "preview": "ファイル名のプレビュー", "old": "現在のファイル名", "new": "新しいファイル名", "rename": "ファイル名を変更",
        "cancel": "キャンセル", "count": "{n} 個のファイル", "hint": "このフォルダー内のファイルのみ変更し、サブフォルダーは変更しません。",
        "confirm": "このフォルダーの {n} 個のファイル名を変更しますか？", "success": "{n} 個のファイル名を変更しました。",
        "no_folder": "先にフォルダーを選択してください。", "choose": "フォルダーを選択", "window": "ファイル順序設定",
    },
    "한국어": {
        "subtitle": "이름을 바꿀 파일이 있는 폴더를 선택하세요.", "folder": "파일 폴더", "browse": "찾아보기...",
        "preview": "파일 이름 미리 보기", "old": "현재 파일 이름", "new": "새 파일 이름", "rename": "파일 이름 변경",
        "cancel": "취소", "count": "파일 {n}개", "hint": "이 폴더의 파일만 변경되며 하위 폴더는 변경되지 않습니다.",
        "confirm": "이 폴더의 파일 {n}개의 이름을 바꿀까요?", "success": "파일 {n}개의 이름을 변경했습니다.",
        "no_folder": "먼저 폴더를 선택하세요.", "choose": "폴더 선택", "window": "파일 정렬 설정",
    },
    "Français": {
        "subtitle": "Choisissez le dossier contenant les fichiers à renommer.", "folder": "Dossier des fichiers", "browse": "Parcourir...",
        "preview": "Aperçu des noms", "old": "NOM ACTUEL", "new": "NOUVEAU NOM", "rename": "Renommer les fichiers",
        "cancel": "Annuler", "count": "{n} fichiers", "hint": "Seuls les fichiers de ce dossier seront renommés, pas les sous-dossiers.",
        "confirm": "Renommer les {n} fichiers de ce dossier ?", "success": "{n} fichiers renommés.",
        "no_folder": "Choisissez d'abord un dossier.", "choose": "Choisir un dossier", "window": "Configuration des fichiers",
    },
    "Deutsch": {
        "subtitle": "Wähle den Ordner mit den Dateien, die umbenannt werden sollen.", "folder": "Dateiordner", "browse": "Durchsuchen...",
        "preview": "Dateinamen-Vorschau", "old": "BISHERIGER NAME", "new": "NEUER NAME", "rename": "Dateien umbenennen",
        "cancel": "Abbrechen", "count": "{n} Dateien", "hint": "Nur Dateien in diesem Ordner werden umbenannt; Unterordner bleiben unverändert.",
        "confirm": "{n} Dateien in diesem Ordner umbenennen?", "success": "{n} Dateien wurden umbenannt.",
        "no_folder": "Bitte zuerst einen Ordner auswählen.", "choose": "Ordner wählen", "window": "Dateien sortieren – Setup",
    },
    "Türkçe": {
        "subtitle": "Yeniden adlandırılacak dosyaların bulunduğu klasörü seçin.", "folder": "Dosya klasörü", "browse": "Gözat...",
        "preview": "Dosya adı önizlemesi", "old": "MEVCUT DOSYA ADI", "new": "YENİ DOSYA ADI", "rename": "Dosyaları yeniden adlandır",
        "cancel": "İptal", "count": "{n} dosya", "hint": "Yalnızca bu klasördeki dosyalar yeniden adlandırılır; alt klasörler değişmez.",
        "confirm": "Bu klasördeki {n} dosya yeniden adlandırılsın mı?", "success": "{n} dosya yeniden adlandırıldı.",
        "no_folder": "Önce bir klasör seçin.", "choose": "Klasör seç", "window": "Dosya Sıralama Kurulumu",
    },
    "Tiếng Việt": {
        "subtitle": "Chọn thư mục chứa các tệp bạn muốn đổi tên.", "folder": "Thư mục tệp", "browse": "Duyệt...",
        "preview": "Xem trước tên tệp", "old": "TÊN HIỆN TẠI", "new": "TÊN MỚI", "rename": "Đổi tên tệp",
        "cancel": "Hủy", "count": "{n} tệp", "hint": "Chỉ đổi tên tệp trong thư mục này; thư mục con không bị thay đổi.",
        "confirm": "Đổi tên {n} tệp trong thư mục này?", "success": "Đã đổi tên {n} tệp.",
        "no_folder": "Vui lòng chọn thư mục trước.", "choose": "Chọn thư mục", "window": "Thiết lập sắp xếp tệp",
    },
    "ไทย": {
        "subtitle": "เลือกโฟลเดอร์ที่มีไฟล์ที่ต้องการเปลี่ยนชื่อ", "folder": "โฟลเดอร์ไฟล์", "browse": "เรียกดู...",
        "preview": "ตัวอย่างชื่อไฟล์", "old": "ชื่อไฟล์เดิม", "new": "ชื่อไฟล์ใหม่", "rename": "เปลี่ยนชื่อไฟล์",
        "cancel": "ยกเลิก", "count": "{n} ไฟล์", "hint": "เปลี่ยนชื่อเฉพาะไฟล์ในโฟลเดอร์นี้ ไม่เปลี่ยนโฟลเดอร์ย่อย",
        "confirm": "เปลี่ยนชื่อไฟล์ {n} ไฟล์ในโฟลเดอร์นี้หรือไม่?", "success": "เปลี่ยนชื่อไฟล์ {n} ไฟล์แล้ว",
        "no_folder": "โปรดเลือกโฟลเดอร์ก่อน", "choose": "เลือกโฟลเดอร์", "window": "ตั้งค่าเรียงไฟล์",
    },
    "اردو": {
        "subtitle": "ان فائلوں والا فولڈر منتخب کریں جن کے نام بدلنے ہیں۔", "folder": "فائلوں کا فولڈر", "browse": "براؤز...",
        "preview": "فائل نام کا پیش منظر", "old": "موجودہ نام", "new": "نیا نام", "rename": "فائلوں کے نام بدلیں",
        "cancel": "منسوخ", "count": "{n} فائلیں", "hint": "صرف اسی فولڈر کی فائلوں کے نام بدلیں گے؛ ذیلی فولڈر نہیں بدلیں گے۔",
        "confirm": "کیا اس فولڈر کی {n} فائلوں کے نام بدلیں؟", "success": "{n} فائلوں کے نام بدل دیے گئے۔",
        "no_folder": "پہلے فولڈر منتخب کریں۔", "choose": "فولڈر منتخب کریں", "window": "فائل ترتیب سیٹ اپ",
    },
    "فارسی": {
        "subtitle": "پوشه‌ای را که فایل‌های موردنظر در آن هستند انتخاب کنید.", "folder": "پوشه فایل‌ها", "browse": "مرور...",
        "preview": "پیش‌نمایش نام فایل", "old": "نام فعلی", "new": "نام جدید", "rename": "تغییر نام فایل‌ها",
        "cancel": "لغو", "count": "{n} فایل", "hint": "فقط فایل‌های این پوشه تغییر می‌کنند؛ زیرپوشه‌ها تغییر نمی‌کنند.",
        "confirm": "نام {n} فایل در این پوشه تغییر کند؟", "success": "نام {n} فایل تغییر کرد.",
        "no_folder": "ابتدا یک پوشه انتخاب کنید.", "choose": "انتخاب پوشه", "window": "تنظیم مرتب‌سازی فایل",
    },
    "Italiano": {
        "subtitle": "Scegli la cartella che contiene i file da rinominare.", "folder": "Cartella dei file", "browse": "Sfoglia...",
        "preview": "Anteprima dei nomi", "old": "NOME ATTUALE", "new": "NUOVO NOME", "rename": "Rinomina file",
        "cancel": "Annulla", "count": "{n} file", "hint": "Vengono rinominati solo i file in questa cartella, non le sottocartelle.",
        "confirm": "Rinominare i {n} file in questa cartella?", "success": "{n} file rinominati.",
        "no_folder": "Scegli prima una cartella.", "choose": "Scegli cartella", "window": "Impostazione ordinamento file",
    },
    "Polski": {
        "subtitle": "Wybierz folder zawierający pliki do zmiany nazw.", "folder": "Folder plików", "browse": "Przeglądaj...",
        "preview": "Podgląd nazw plików", "old": "OBECNA NAZWA", "new": "NOWA NAZWA", "rename": "Zmień nazwy plików",
        "cancel": "Anuluj", "count": "{n} plików", "hint": "Zmieniane są tylko pliki w tym folderze; podfoldery pozostają bez zmian.",
        "confirm": "Zmienić nazwy {n} plików w tym folderze?", "success": "Zmieniono nazwy {n} plików.",
        "no_folder": "Najpierw wybierz folder.", "choose": "Wybierz folder", "window": "Konfiguracja sortowania plików",
    },
    "Українська": {
        "subtitle": "Виберіть папку з файлами, які потрібно перейменувати.", "folder": "Папка з файлами", "browse": "Огляд...",
        "preview": "Попередній перегляд назв", "old": "ПОТОЧНА НАЗВА", "new": "НОВА НАЗВА", "rename": "Перейменувати файли",
        "cancel": "Скасувати", "count": "{n} файлів", "hint": "Змінюються лише файли в цій папці; підпапки не змінюються.",
        "confirm": "Перейменувати {n} файлів у цій папці?", "success": "Перейменовано файлів: {n}.",
        "no_folder": "Спочатку виберіть папку.", "choose": "Вибрати папку", "window": "Налаштування сортування файлів",
    },
    "Bahasa Melayu": {
        "subtitle": "Pilih folder yang mengandungi fail yang ingin dinamakan semula.", "folder": "Folder fail", "browse": "Semak imbas...",
        "preview": "Pratonton nama fail", "old": "NAMA ASAL", "new": "NAMA BAHARU", "rename": "Namakan Semula Fail",
        "cancel": "Batal", "count": "{n} fail", "hint": "Hanya fail dalam folder ini dinamakan semula; subfolder tidak berubah.",
        "confirm": "Namakan semula {n} fail dalam folder ini?", "success": "{n} fail berjaya dinamakan semula.",
        "no_folder": "Pilih folder dahulu.", "choose": "Pilih Folder", "window": "Persediaan Susun Fail",
    },
    "Filipino": {
        "subtitle": "Piliin ang folder na may mga file na papalitan ang pangalan.", "folder": "Folder ng mga file", "browse": "Mag-browse...",
        "preview": "Preview ng pangalan ng file", "old": "KASALUKUYANG PANGALAN", "new": "BAGONG PANGALAN", "rename": "Palitan ang Pangalan",
        "cancel": "Kanselahin", "count": "{n} file", "hint": "Mga file lang sa folder na ito ang papalitan; hindi gagalawin ang mga subfolder.",
        "confirm": "Palitan ang pangalan ng {n} file sa folder na ito?", "success": "Napaltan ang pangalan ng {n} file.",
        "no_folder": "Pumili muna ng folder.", "choose": "Pumili ng Folder", "window": "Setup ng Pag-aayos ng File",
    },
    "עברית": {
        "subtitle": "בחרו תיקייה שמכילה את הקבצים שברצונכם לשנות את שמם.", "folder": "תיקיית קבצים", "browse": "עיון...",
        "preview": "תצוגה מקדימה של שמות", "old": "שם קובץ נוכחי", "new": "שם קובץ חדש", "rename": "שינוי שמות קבצים",
        "cancel": "ביטול", "count": "{n} קבצים", "hint": "רק הקבצים בתיקייה זו ישונו; תיקיות משנה לא ישתנו.",
        "confirm": "לשנות את שמות {n} הקבצים בתיקייה זו?", "success": "שמות {n} קבצים שונו.",
        "no_folder": "יש לבחור תיקייה תחילה.", "choose": "בחירת תיקייה", "window": "הגדרת סידור קבצים",
    },
    "Nederlands": {
        "subtitle": "Kies de map met de bestanden waarvan je de naam wilt wijzigen.", "folder": "Bestandenmap", "browse": "Bladeren...",
        "preview": "Voorbeeld van bestandsnamen", "old": "HUIDIGE BESTANDSNAAM", "new": "NIEUWE BESTANDSNAAM", "rename": "Bestanden hernoemen",
        "cancel": "Annuleren", "count": "{n} bestanden", "hint": "Alleen bestanden in deze map worden hernoemd; submappen blijven ongewijzigd.",
        "confirm": "{n} bestanden in deze map hernoemen?", "success": "{n} bestanden hernoemd.",
        "no_folder": "Kies eerst een map.", "choose": "Map kiezen", "window": "Bestanden ordenen – Setup",
    },
}

# Ensure exactly 25 language choices.
assert len(LANGUAGES) == 25, len(LANGUAGES)

BG = "#f0f0f0"
WHITE = "#ffffff"
BLUE = "#0878d1"
BLUE_HOVER = "#0067b8"
TEXT = "#222222"
MUTED = "#666666"
BORDER = "#c8c8c8"


class FileRenamerApp:
    def __init__(self, root):
        self.root = root
        self.root.geometry("900x650")
        self.root.minsize(760, 570)
        self.root.configure(bg=BG)
        self.folder = None
        self.files = []
        self.language = tk.StringVar(value="Bahasa Indonesia")
        self._style()
        self._build()
        self.apply_language()

    def _style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Treeview", background=WHITE, fieldbackground=WHITE,
                        foreground=TEXT, rowheight=27, borderwidth=1,
                        font=("Segoe UI", 10))
        style.configure("Treeview.Heading", background="#eeeeee", foreground=TEXT,
                        relief="groove", font=("Segoe UI", 9, "bold"), padding=7)
        style.map("Treeview", background=[("selected", "#cce8ff")],
                  foreground=[("selected", TEXT)])
        style.configure("TCombobox", padding=4)

    def _build(self):
        # Installer-style title and language selector in the upper-left corner.
        top = tk.Frame(self.root, bg=BG, padx=16, pady=10)
        top.pack(fill="x")
        tk.Label(top, text="🌐", bg=BG, fg=TEXT, font=("Segoe UI", 12)).pack(side="left", padx=(0, 5))
        self.lang_label = tk.Label(top, text="Language / Bahasa:", bg=BG, fg=TEXT,
                                   font=("Segoe UI", 9))
        self.lang_label.pack(side="left")
        self.lang_combo = ttk.Combobox(top, textvariable=self.language,
                                       values=list(LANGUAGES.keys()), state="readonly", width=20)
        self.lang_combo.pack(side="left", padx=(7, 0))
        self.lang_combo.bind("<<ComboboxSelected>>", lambda _e: self.apply_language())

        tk.Frame(self.root, bg="#d6d6d6", height=1).pack(fill="x")
        intro = tk.Frame(self.root, bg=WHITE, padx=22, pady=15)
        intro.pack(fill="x")
        tk.Label(intro, text="Urutkan File Setup", bg=WHITE, fg=TEXT,
                 font=("Segoe UI", 15, "bold")).pack(anchor="w")
        self.subtitle_label = tk.Label(intro, text="", bg=WHITE, fg=TEXT,
                                        font=("Segoe UI", 10))
        self.subtitle_label.pack(anchor="w", pady=(4, 0))
        tk.Frame(self.root, bg="#bcbcbc", height=1).pack(fill="x")

        self.content = tk.Frame(self.root, bg=BG, padx=28, pady=18)

        self.folder_label = tk.Label(self.content, text="", bg=BG, fg=TEXT,
                                     font=("Segoe UI", 10, "bold"))
        self.folder_label.pack(anchor="w", pady=(0, 7))
        folder_row = tk.Frame(self.content, bg=BG)
        folder_row.pack(fill="x")
        self.folder_var = tk.StringVar(value="")
        self.folder_entry = tk.Entry(folder_row, textvariable=self.folder_var,
                                     font=("Segoe UI", 10), relief="sunken",
                                     bd=1, bg=WHITE, fg=TEXT)
        self.folder_entry.pack(side="left", fill="x", expand=True, ipady=6)
        self.browse_btn = tk.Button(folder_row, text="", command=self.choose_folder,
                                    bg=WHITE, fg=TEXT, activebackground="#e5f3ff",
                                    relief="raised", bd=1, cursor="hand2",
                                    font=("Segoe UI", 9), padx=16, pady=6)
        self.browse_btn.pack(side="left", padx=(10, 0))

        self.preview_label = tk.Label(self.content, text="", bg=BG, fg=TEXT,
                                      font=("Segoe UI", 10, "bold"))
        self.preview_label.pack(anchor="w", pady=(18, 7))
        table_frame = tk.Frame(self.content, bg=WHITE, bd=1, relief="sunken")
        table_frame.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(table_frame, columns=("old", "new"), show="headings")
        self.tree.heading("old", text="")
        self.tree.heading("new", text="")
        self.tree.column("old", width=360, anchor="w")
        self.tree.column("new", width=260, anchor="w")
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        self.hint_label = tk.Label(self.content, text="", bg=BG, fg=MUTED,
                                   font=("Segoe UI", 9))
        self.hint_label.pack(anchor="w", pady=(8, 0))

        # Footer is packed before the expanding content so it stays visible.
        self.footer = tk.Frame(self.root, bg=BG, padx=18, pady=12)
        tk.Frame(self.root, bg="#bcbcbc", height=1).pack(fill="x", side="bottom")
        self.cancel_btn = tk.Button(self.footer, text="", command=self.root.destroy,
                                    bg=WHITE, fg=TEXT, activebackground="#e5f3ff",
                                    relief="raised", bd=1, cursor="hand2",
                                    font=("Segoe UI", 9), padx=20, pady=6)
        self.cancel_btn.pack(side="right", padx=(8, 0))
        self.rename_btn = tk.Button(self.footer, text="", command=self.rename_files,
                                    bg=BLUE, fg=WHITE, activebackground=BLUE_HOVER,
                                    activeforeground=WHITE, relief="raised", bd=1,
                                    cursor="hand2", font=("Segoe UI", 9, "bold"),
                                    padx=22, pady=6, state="disabled")
        self.rename_btn.pack(side="right")
        self.footer.pack(fill="x", side="bottom")
        self.content.pack(fill="both", expand=True)

    def t(self, key, **kwargs):
        data = LANGUAGES.get(self.language.get(), LANGUAGES["English"])
        value = data.get(key, LANGUAGES["English"].get(key, key))
        return value.format(**kwargs) if kwargs else value

    def apply_language(self):
        self.root.title(self.t("window"))
        self.subtitle_label.config(text=self.t("subtitle"))
        self.folder_label.config(text=self.t("folder"))
        self.browse_btn.config(text=self.t("browse"))
        self.preview_label.config(text=self.t("preview"))
        self.tree.heading("old", text=self.t("old"))
        self.tree.heading("new", text=self.t("new"))
        self.rename_btn.config(text=self.t("rename"))
        self.cancel_btn.config(text=self.t("cancel"))
        self.hint_label.config(text=self.t("hint"))
        self.refresh_preview()

    def choose_folder(self):
        selected = filedialog.askdirectory(title=self.t("choose"))
        if selected:
            self.folder = Path(selected)
            self.folder_var.set(selected)
            self.refresh_preview()

    def refresh_preview(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        if self.folder:
            try:
                self.files = sorted([p for p in self.folder.iterdir() if p.is_file()],
                                    key=lambda p: p.name.casefold())
            except OSError as exc:
                messagebox.showerror("Error", str(exc))
                self.files = []
            for i, path in enumerate(self.files, start=1):
                self.tree.insert("", "end", values=(path.name, f"{i}{path.suffix}"))
        else:
            self.files = []
        self.rename_btn.config(state=("normal" if self.files else "disabled"))

    def rename_files(self):
        if not self.folder:
            messagebox.showinfo(self.t("window"), self.t("no_folder"))
            return
        if not self.files:
            return
        n = len(self.files)
        if not messagebox.askyesno(self.t("rename"), self.t("confirm", n=n)):
            return
        try:
            current = sorted([p for p in self.folder.iterdir() if p.is_file()],
                             key=lambda p: p.name.casefold())
            # Stage all files to unique temporary names to avoid collisions.
            staged = []
            for path in current:
                temp = self.folder / f".urutkan_tmp_{uuid.uuid4().hex}{path.suffix}"
                path.rename(temp)
                staged.append((temp, path))
            renamed = []
            try:
                for index, (temp, original) in enumerate(staged, start=1):
                    target = self.folder / f"{index}{original.suffix}"
                    if target.exists():
                        raise FileExistsError(target.name)
                    temp.rename(target)
                    renamed.append((target, original))
            except Exception:
                # Best-effort restoration if an unexpected filesystem error occurs.
                for temp, original in staged:
                    candidate = self.folder / f"{staged.index((temp, original)) + 1}{original.suffix}"
                    source = candidate if candidate.exists() else temp
                    if source.exists() and not original.exists():
                        try:
                            source.rename(original)
                        except OSError:
                            pass
                raise
            messagebox.showinfo(self.t("window"), self.t("success", n=len(renamed)))
            self.refresh_preview()
        except Exception as exc:
            messagebox.showerror("Error", str(exc))
            self.refresh_preview()


if __name__ == "__main__":
    root = tk.Tk()
    app = FileRenamerApp(root)
    root.mainloop()
